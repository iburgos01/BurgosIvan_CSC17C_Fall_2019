/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on Sept 8th, 2019, 5:00 PM
 * Purpose:  Triangular array in Order as a Structure
 */

//System Libraries Here
#include <iostream>  //I/O Library
#include <cstdlib>   //Random function Library
#include <ctime>     //Time Library
using namespace std;

//User Libraries Here
#include "TriMatx.h"
//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
TriMatx fillAry(TriMatx);       //Randomly fill a triangular array
//int *fillAry(int);             //Randomly fill a 1-D column array
void prntAry(int *,int);       //Print a 1-D array
void prntAry(int **,int *,int);//Print a triangular array
//Mod the original with the following indexed array using a database sort idea
void destroy(TriMatx);//Deallocate memory
//int *filIndx(int);                   //Fill the index
//You code these functions using concepts and programs already discussed
void markSrt(TriMatx);       //Sort the columns using the index
void prntAry(TriMatx);//Print a triangular array col size order

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    //srand(static_cast<unsigned int>(time(0)));
    cout<<"Triangular Matrix Program"<<endl;
    cout<<"Input a positive signed integer for the seed"<<endl;
    cout<<"to the random number generator"<<endl;
    cout<<"This allows for repeatability"<<endl;
    int seed;
    cin>>seed;
    srand(seed);
    
    //Declare all Variables Here
    TriMatx array;   //Structure to hold info
//    int *col;      //Pointer to column array
//    int **trangl;  //Pointer to triangular array
//    int *indx;     //Pointer to the indexed array
    
    //Input or initialize values Here
    array.size=10;             //Literal column array size
    array=fillAry(array);       //Dynamic 1-D array
                                //Fill the index
                                //Dynamic triangular array

    //Sort the columns
    markSrt(array);  //Sort with the index
    
    //Output Located Here
    cout<<"The original Column Matrix"<<endl;
    prntAry(array.col,array.size);       //Print the original col size for each row
    cout<<endl<<"The sorted Index Array"<<endl;
    prntAry(array.indx,array.size);      //Print the sorted index of column sizes
    cout<<endl<<"The unsorted Triangular Matrx"<<endl;
    prntAry(array.data,array.col,array.size);//Print the Triangular matrix unsorted
    cout<<endl<<"The Triangular Matrix printed by smallest column to largest"<<endl;
    prntAry(array);//Print the Triangular matrix sorted by col

    //Deallocate the array
    destroy(array);//Clean up the results
    
    //Exit
    return 0;
}



//Implement a database sort using an index.  Sort the index not the data.
void markSrt(TriMatx a){
    //Your Code Here
    for(int i=0;i<a.size-1;i++){
        for(int j=i+1;j<a.size;j++){
            //Swap the positions of the index
            if(a.col[a.indx[i]]>a.col[a.indx[j]]){
                a.indx[i]=a.indx[i]^a.indx[j];
                a.indx[j]=a.indx[i]^a.indx[j];
                a.indx[i]=a.indx[i]^a.indx[j];
            }
        }
    }
}


//Print the sorted Triangular matrix using the index!
void prntAry(TriMatx array){
    //Your Code Here
    for(int i=0;i<array.size;i++){
        for(int j=0;j<array.col[array.indx[i]];j++){
            cout<<array.data[array.indx[i]][j]<<" ";
        }
        cout<<endl;
    }
}

//Destroy all dynamically created arrays
void destroy(TriMatx a){
    //Delete every row of the triangular array
    for(int i=0;i<a.size;i++){
        delete a.data[i];
    }
    //Delete the pointers
    delete []a.data;
    delete []a.col;
    delete []a.indx;  
}

//Fill a triangular matrix
TriMatx fillAry(TriMatx array){
    array.col=new int[array.size];
    for(int i=0;i<array.size;i++){
        array.col[i]=rand()%9+1;//1 Digit numbers [1-9]
    }
    
    array.data=new int*[array.size];
    for(int i=0;i<array.size;i++){
        array.data[i]=new int[array.col[i]];
    }
    for(int i=0;i<array.size;i++){
        for(int j=0;j<array.col[i];j++){
            array.data[i][j]=rand()%9+1;//1 Digit numbers [1-9]
        }
    }
    
    array.indx=new int[array.size];
    for(int i=0;i<array.size;i++){
        array.indx[i]=i;
    }
    
    return array;
}

//Print the triangular matrix
void prntAry(int **array,int *col,int n){
    cout<<endl;
    for(int i=0;i<n;i++){
        for(int j=0;j<col[i];j++){
            cout<<array[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
}

//Print the array
void prntAry(int *a,int n){
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
}

//Randomly fill the column size with 1 digit numbers
int *fillAry(int n){
    
}