/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 22, 2019, 7:35 PM
 * Purpose:  Create vector that can add or drop a value
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
#include "SimpleVector.h"
//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int size=10;
    int choice;
    int value,popVal;
    SimpleVector<int> vect(size);
    //Initialize Variables
    
    //Process/Map inputs to outputs
    cout<<"Choose to push or pop: "<<endl
        <<"1.push back"<<endl
        <<"2.pop back "<<endl
        <<"3.push front "<<endl
        <<"4.pop front"<<endl;    
    cin>>choice;

    switch(choice){
        case 1: {
            cout<<"Enter value to push back"<<endl;
            cin>>value;
            vect.push_back(value);
            size++;
        }break;
        case 2: {
            popVal=vect.pop_back();
            cout<<"Pop value is "<<popVal<<endl;
            size--;
        }break;
        case 3:{
            cout<<"Enter the value to be added to the front"<<endl;
            cin>>value;
            vect.push_front(value);
            size++;
        }break;
        case 4:{
            popVal=vect.pop_front();
            cout<<"Pop value is "<<popVal<<endl;
            size--;
        }break;
        }
    //Output data
    for(int i=0;i<size;i++){
        cout<<" "<<vect.getElementAt(i);
    }
    //Exit stage right!
    return 0;
}